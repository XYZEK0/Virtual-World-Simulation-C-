#pragma once
#include "Roslina.h"

class Mlecz :public Roslina
{
	public:
		Mlecz(Vector* pos, Swiat* world);
		void akcja(Swiat* swiat) override;
		void kolizja(Swiat* swiat, Organizm* org) override;
};