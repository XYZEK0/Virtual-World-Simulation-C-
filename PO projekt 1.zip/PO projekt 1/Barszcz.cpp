#include "Barszcz.h"
#include <iostream>
#include "Swiat.h"
Barszcz::Barszcz(Vector* pos, Swiat* sw) : Roslina(10, 0, pos, 'X', sw)
{
	;
}

void Barszcz::akcja(Swiat* swiat)
{
	//std::cout << this->pos->getX() << " " << this->pos->getY() << " ";
	//std::cout << "Akcja Barszczu!" << std::endl;
	eksterminacja(swiat);
	int number = rand() % 5;
	if (number == 0)
		this->Roslina::akcja(swiat);
}

void Barszcz::kolizja(Swiat* swiat,Organizm*org)
{
	vector<Organizm*>temp;
	vector<Organizm*>temp1;0
	std::cout << "Kolizja Barszcz z " << org->getZnak() << std::endl;
	if (org->getZnak() != 'C')
	{
		
		swiat->getOrganizmy()[org->getPos()->getY()][org->getPos()->getX()] = NULL;
		temp = swiat->getVector();
		temp1 = swiat->getVectorZywe();
		for (int i = 0; i < temp1.size(); i++)
		{

			if (temp1[i] == org) temp1.erase(temp1.begin() + i);
		}
		for (int i = 0; i < temp.size(); i++)
		{
			if (temp[i] == org) temp.erase(temp.begin() + i);
		}
	}
	else
	{
		
		swiat->getOrganizmy()[this->getPos()->getY()][this->getPos()->getX()] = NULL;
		temp = swiat->getVector();
		temp1 = swiat->getVectorZywe();
		for (int i = 0; i < temp1.size(); i++)
		{
			if (temp1[i] == this) temp1.erase(temp1.begin() + i);
		}
		for (int i = 0; i < temp.size(); i++)
		{
			if (temp[i] == this) temp.erase(temp.begin() + i);
		}
	}

	swiat->setVector(temp);
	swiat->setVectorZywe(temp1);
}

void Barszcz::eksterminacja(Swiat* swiat)
{
	
	vector<Organizm*>temp;
	vector<Organizm*>temp1;
	Organizm* org;
	temp = swiat->getVector();
	temp1 = swiat->getVectorZywe();
	org = swiat->getOrganizmy()[this->getPos()->getY() + 1][this->getPos()->getX()];
	if(org!=NULL)
	{ 
		if(org->getZnak()!='C' && org->getZnak() != 'X')
		{ 
			swiat->getOrganizmy()[this->getPos()->getY() + 1][this->getPos()->getX()] = NULL;
			for (int i = 0; i < temp1.size(); i++)
			{
				if (temp1[i] == org) temp1.erase(temp1.begin() + i);
			}
			for (int i = 0; i < temp.size(); i++)
			{
				if (temp[i] == org) temp.erase(temp.begin() + i);
			}
		}
	}
	org = swiat->getOrganizmy()[this->getPos()->getY() - 1][this->getPos()->getX()];
	if (org != NULL)
	{
		if (org->getZnak() != 'C' && org->getZnak() != 'X')
		{
			swiat->getOrganizmy()[this->getPos()->getY() - 1][this->getPos()->getX()] = NULL;
			for (int i = 0; i < temp1.size(); i++)
			{
				if (temp1[i] == org) temp1.erase(temp1.begin() + i);
			}
			for (int i = 0; i < temp.size(); i++)
			{
				if (temp[i] == org) temp.erase(temp.begin() + i);
			}
		}
	}
	org = swiat->getOrganizmy()[this->getPos()->getY() + 1][this->getPos()->getX() - 1];
	if (org != NULL)
	{
		if (org->getZnak() != 'C' && org->getZnak() != 'X')
		{
			swiat->getOrganizmy()[this->getPos()->getY() + 1][this->getPos()->getX() - 1] = NULL;
			for (int i = 0; i < temp1.size(); i++)
			{
				if (temp1[i] == org) temp1.erase(temp1.begin() + i);
			}
			for (int i = 0; i < temp.size(); i++)
			{
				if (temp[i] == org) temp.erase(temp.begin() + i);
			}
		}
	}
	org = swiat->getOrganizmy()[this->getPos()->getY() + 1][this->getPos()->getX() + 1];
	if (org != NULL)
	{
		if (org->getZnak() != 'C' && org->getZnak() != 'X')
		{
			swiat->getOrganizmy()[this->getPos()->getY() + 1][this->getPos()->getX() + 1] = NULL;
			for (int i = 0; i < temp1.size(); i++)
			{
				if (temp1[i] == org) temp1.erase(temp1.begin() + i);
			}
			for (int i = 0; i < temp.size(); i++)
			{
				if (temp[i] == org) temp.erase(temp.begin() + i);
			}
		}
	}
	org = swiat->getOrganizmy()[this->getPos()->getY()][this->getPos()->getX() + 1];
	if (org != NULL)
	{
		if (org->getZnak() != 'C' && org->getZnak() != 'X')
		{
			swiat->getOrganizmy()[this->getPos()->getY()][this->getPos()->getX() + 1] = NULL;
			for (int i = 0; i < temp1.size(); i++)
			{
				if (temp1[i] == org) temp1.erase(temp1.begin() + i);
			}
			for (int i = 0; i < temp.size(); i++)
			{
				if (temp[i] == org) temp.erase(temp.begin() + i);
			}
		}
	}
	org = swiat->getOrganizmy()[this->getPos()->getY()][this->getPos()->getX() - 1];
	if (org != NULL)
	{
		if (org->getZnak() != 'C' && org->getZnak() != 'X')
		{
			swiat->getOrganizmy()[this->getPos()->getY()][this->getPos()->getX() - 1] = NULL;
			for (int i = 0; i < temp1.size(); i++)
			{
				if (temp1[i] == org) temp1.erase(temp1.begin() + i);
			}
			for (int i = 0; i < temp.size(); i++)
			{
				if (temp[i] == org) temp.erase(temp.begin() + i);
			}
		}
	}
	org = swiat->getOrganizmy()[this->getPos()->getY() - 1][this->getPos()->getX() + 1];
	if (org != NULL)
	{
		if (org->getZnak() != 'C' && org->getZnak() != 'X')
		{
			swiat->getOrganizmy()[this->getPos()->getY() - 1][this->getPos()->getX() + 1] = NULL;
			for (int i = 0; i < temp1.size(); i++)
			{
				if (temp1[i] == org) temp1.erase(temp1.begin() + i);
			}
			for (int i = 0; i < temp.size(); i++)
			{
				if (temp[i] == org) temp.erase(temp.begin() + i);
			}
		}
	}
	org = swiat->getOrganizmy()[this->getPos()->getY() - 1][this->getPos()->getX() - 1];
	if (org != NULL)
	{
		if (org->getZnak() != 'C' && org->getZnak() != 'X')
		{
			swiat->getOrganizmy()[this->getPos()->getY() - 1][this->getPos()->getX() - 1] = NULL;
			for (int i = 0; i < temp1.size(); i++)
			{
				if (temp1[i] == org) temp1.erase(temp1.begin() + i);
			}
			for (int i = 0; i < temp.size(); i++)
			{
				if (temp[i] == org) temp.erase(temp.begin() + i);
			}
		}
	}
	swiat->setVector(temp);
	swiat->setVectorZywe(temp1);
	
}