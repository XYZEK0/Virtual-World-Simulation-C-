#include "Antylopa.h"
#include "Swiat.h"
#include <iostream>

Antylopa::Antylopa(Vector* pos, Swiat* sw) : Zwierze(4, 4, pos, 'A', sw)
{
	;
}

void Antylopa::akcja(Swiat* swiat)
{
	//std::cout << this->pos->getX() << " " << this->pos->getY() << " ";
	//std::cout << "Akcja Antylopy!" << std::endl;
	this->setCanMove(true);
	oldPos = pos;
	int number;
	bool hasMoved = false;

	Vector* destination = NULL;
	while (!hasMoved)
	{
		number = rand() % 4;
		switch (number)
		{
		case 0:
			if (this->pos->getY() - 2 > 0)
			{
				destination = new Vector(this->getPos()->getX(), this->getPos()->getY() - 2);
				hasMoved = true;
			}
			break;
		case 1:
			if (this->pos->getY() + 2 < swiat->getSizeY() - 1)
			{
				destination = new Vector(this->getPos()->getX(), this->getPos()->getY() + 2);
				hasMoved = true;
			}
			break;
		case 2:
			if (this->pos->getX() - 2 > 0)
			{
				destination = new Vector(this->getPos()->getX() - 2, this->getPos()->getY());
				hasMoved = true;
			}
			break;
		case 3:
			if (this->pos->getX() + 2 < swiat->getSizeX() - 1)
			{
				destination = new Vector(this->getPos()->getX() + 2, this->getPos()->getY());
				hasMoved = true;
			}
			break;
		default: std::cout << "Blad w ruchu!" << std::endl; break;
		}
	}
	
	if (swiat->getOrganizmy()[destination->getY()][destination->getX()] != NULL)
	{										  				   	   
		swiat->getOrganizmy()[destination->getY()][destination->getX()]->kolizja(swiat,this);
	}

	if(this->getCanMove())
	this->setPos(destination);
}

void Antylopa::kolizja(Swiat* swiat, Organizm* org)
{

	if (this->getZnak() == org->getZnak())
	{
		org->setCanMove(false);
		this->Zwierze::kolizja(swiat, org);
	}
	else
	{
		
		std::cout << "Kolizja Antylopy z " << org->getZnak() << std::endl;
		int number = rand() % 4;
		if (number > 1)
		{
			cout << "Antylopie uda�o si� uciec przed " << org->getZnak() << endl;
			this->setCanMove(false);
			if (this->pos->getY() - 2 > 0 && swiat->getOrganizmy()[this->pos->getY() - 2][this->pos->getX()] == NULL)
			{
				this->setPos(new Vector(this->getPos()->getX(), this->getPos()->getY() - 2));
			}
			else if (this->pos->getY() + 2 < swiat->getSizeY() - 1 && swiat->getOrganizmy()[this->pos->getY() + 2][this->pos->getX()] == NULL)
			{
				this->setPos(new Vector(this->getPos()->getX(), this->getPos()->getY() + 2));
			}
			else if (this->pos->getX() - 2 > 0 && swiat->getOrganizmy()[this->pos->getY()][this->pos->getX() - 2] == NULL)
			{
				this->setPos(new Vector(this->getPos()->getX() - 2, this->getPos()->getY()));
			}
			else if (this->pos->getX() + 2 < swiat->getSizeX() - 1 && swiat->getOrganizmy()[this->pos->getY()][this->pos->getX() + 2] == NULL)
			{
				this->setPos(new Vector(this->getPos()->getX() + 2, this->getPos()->getY()));
			}
			else
			{
				int number = rand() % 4;
				switch (number)
				{
				case 0:
					if (this->pos->getY() - 2 > 0)
					{
						this->setPos(new Vector(this->getPos()->getX(), this->getPos()->getY() - 2));
					}
					break;
				case 1:
					if (this->pos->getY() + 2 < swiat->getSizeY() - 1)
					{
						this->setPos(new Vector(this->getPos()->getX(), this->getPos()->getY() + 2));
					}
					break;
				case 2:
					if (this->pos->getX() - 2 > 0)
					{
						this->setPos(new Vector(this->getPos()->getX() - 2, this->getPos()->getY()));
					}
					break;
				case 3:
					if (this->pos->getX() + 2 < swiat->getSizeX() - 1)
					{
						this->setPos(new Vector(this->getPos()->getX() + 2, this->getPos()->getY()));
					}
					break;
				}
			}

		}
		else this->Organizm::walka(swiat, org);
	}
	
}