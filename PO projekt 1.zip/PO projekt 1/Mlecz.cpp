#include "Mlecz.h"
#include <iostream>

Mlecz::Mlecz(Vector* pos, Swiat* sw) : Roslina(0, 0, pos, 'M', sw)
{
	;
}

void Mlecz::akcja(Swiat* swiat)
{
	//std::cout << this->pos->getX() << " " << this->pos->getY() << " ";
	//std::cout << "Akcja Mlecza!" << std::endl;

	int number = rand() % 7;
	if (number == 0)
		this->Roslina::akcja(swiat);

	 number = rand() % 7;
	if (number == 0)
		this->Roslina::akcja(swiat);

	 number = rand() % 7;
	if (number == 0)
		this->Roslina::akcja(swiat);
}

void Mlecz::kolizja(Swiat* swiat, Organizm* org)
{
	std::cout << "Kolizja Mlecz z " << org->getZnak() << std::endl;
	this->Organizm::walka(swiat, org);
}