#pragma once
#include "Zwierze.h"

class Czlowiek :public Zwierze
{
private:
	bool isPowerOn;
	bool isPowerOnCooldown;
	int cooldownTurns;
	int powerTurns;
	int moveDistance;
public: 
	Czlowiek(Vector* pos, Swiat* world);

	void akcja(Swiat* swiat) override;
	//void rysowanie() override;
	void kolizja(Swiat*swiat,Organizm* zwierze) override;

	bool getisPowerOn()
	{
		return this->isPowerOn;
	}
	bool getisPowerOnCooldown()
	{
		return this->isPowerOnCooldown;
	}
	int getpowerTurns()
	{
		return powerTurns;
	}
	int getcooldownTurns()
	{
		return this->cooldownTurns;
	}

	void setisPowerOn(bool value)
	{
		this->isPowerOn = value;
	}
	void setisPowerOnCooldown(bool value)
	{
		this->isPowerOnCooldown = value;
	}
	void setpowerTurns(int value)
	{
		this->powerTurns = value;
	}
	void setcooldownTurns(int value)
	{
		this->cooldownTurns = value;
	}

};