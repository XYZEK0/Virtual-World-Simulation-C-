#include "Swiat.h"
#include <iostream>
#include <vector>

using namespace std;


void Swiat::wykonajTure()
{
    
    cout << "Krzysztof Rydel s180502" << endl;
    vector <Organizm*>  orgTab = makeOrganizmyTab(this->organizmy);
    this->setVector(orgTab);
    this->setVectorZywe(orgTab);
    
   
    while (!this->getVector().empty())
    {
        Organizm* temp = this->getVector()[0];

        this->getVector()[0]->akcja(this);
        if (!this->getVector().empty())
        {
            if (this->getVector()[0] == temp)
            {
                this->getVector().erase(this->getVector().begin());
            }
        }
        if (!sprawdzCzyGraczZyje())
        {
            cout << "Gracz zginal!";
            system("pause");
        }
        for (int i = 0; i < this->getSizeY(); i++)
        {
            for (int j = 0; j < this->getSizeX(); j++)
            {
                this->getOrganizmy()[i][j] = NULL;
            }
        }
        for (int i = 0; i < this->getVectorZywe().size(); i++)
        {
            this->getOrganizmy()[this->getVectorZywe()[i]->getPos()->getY()][this->getVectorZywe()[i]->getPos()->getX()] = this->getVectorZywe()[i];
        }
    }
   
    zaktualizujWiek();
    
    rysujSwiat(this);

}

void Swiat::rysujSwiat(Swiat* worldInstance)
{
    for (int i = 0; i < this->getSizeY(); i++)
    {
        for (int j = 0; j < this->getSizeX(); j++)
        {
            if ((i == 0 && j == 0) || (i == 0 && j == this->getSizeX() - 1) || (i == this->getSizeY() - 1 && j == 0) || (i == this->getSizeY() - 1 && j == this->getSizeX() - 1)) worldInstance->getPlansza()[i][j] = '+';
            else if (i == 0 || i == this->getSizeY() - 1) worldInstance->getPlansza()[i][j] = '-';
            else if (j == 0 || j == this->getSizeX() - 1) worldInstance->getPlansza()[i][j] = '|';
            else worldInstance->getPlansza()[i][j] = ' ';
        }
    }
    

    for (int i = 0; i < worldInstance->getSizeY(); i++)
    {
        for (int j = 0; j < worldInstance->getSizeX(); j++)
        {
            if (worldInstance->getOrganizmy()[i][j] != NULL)
            {
                worldInstance->getPlansza()[worldInstance->getOrganizmy()[i][j]->getPos()->getY()][worldInstance->getOrganizmy()[i][j]->getPos()->getX()] = worldInstance->getOrganizmy()[i][j]->getZnak();
            }
        }
    }
    

    for (int i = 0; i < this->getSizeY(); i++)
    {
        for (int j = 0; j < this->getSizeX(); j++)
        {
            cout << worldInstance->getPlansza()[i][j];
        }
        cout << endl;
    }

    wykonajTure();
    
}

void Swiat::zaktualizujWiek()
{
    
        for (int i = 0; i < this->getVectorZywe().size(); i++)
        {
            this->getVectorZywe()[i]->setWiek(this->getVectorZywe()[i]->getWiek() + 1);
        }
    
}

void Swiat::sortujOrganizmy(vector<Organizm*>& organizmy, int first, int last)
{
    if (first < last)
    {
        int parIndex = partycja(organizmy, first, last);
        
        sortujOrganizmy(organizmy, first, parIndex - 1);
        sortujOrganizmy(organizmy, parIndex + 1, last);
    }
}

void Swiat::countOrganizmy3D(Organizm*** organizmy)
{
    int counter = 0;

    for (int i = 0; i < sizeY; i++)
    {
        for (int j = 0; j < sizeX; j++)
        {
            if (this->getOrganizmy()[i][j] != NULL) counter++;
        }
    }

    this->sizeOrganizmy2D = counter;
    
}

void Swiat::swap(Organizm*& org1, Organizm*& org2)
{
    Organizm* temp = org1;
    org1 = org2;
    org2 = temp;
}


bool Swiat::sprawdzCzyGraczZyje()
{
    int players = 0;
    for (int i = 0; i < this->getVectorZywe().size(); i++)
    {
        if (this->getVectorZywe()[i]->getZnak() == 'P') players++;
    }
    if (players == 0) return false;
    else return true;
    
}

int Swiat::partycja(vector<Organizm*>& organizmy, int first, int last)
{
    Organizm* pivot = organizmy[last];

    int i = first - 1;
    
    for (int j = first; j <= last - 1; j++)
    {
        if (organizmy[j]->getInicjatywa() > pivot->getInicjatywa())
        {
            i++;
            swap(organizmy[i], organizmy[j]);
        }
        else if (organizmy[j]->getInicjatywa() == pivot->getInicjatywa())
        {
            if (organizmy[j]->getWiek() > pivot->getWiek())
            {
                i++;
                swap(organizmy[i], organizmy[j]);
            }
        }
    }
    swap(organizmy[i+1], organizmy[last]);

    return (i + 1);
}

Organizm* Swiat::findOrganizm(Swiat* worldInstance, char orgChar)
{
    for (int i = 0; i < worldInstance->getSizeY(); i++)
    {
        for (int j = 0; j < worldInstance->getSizeX(); j++)
        {
            if (worldInstance->getOrganizmy()[i][j]->getZnak() == orgChar)
                return worldInstance->getOrganizmy()[i][j];
        }
    }
    return NULL;
}

vector<Organizm*> Swiat::makeOrganizmyTab(Organizm***organizmy)
{
    vector<Organizm*> orgTab;
   
    for (int i = 0; i < sizeY; i++)
    {
        for (int j = 0; j < sizeX; j++)
        {
            if (this->getOrganizmy()[i][j] != NULL)
            {
                orgTab.push_back(organizmy[i][j]);
            }
        }
    }

    sortujOrganizmy(orgTab, 0, orgTab.size() - 1 );
    return orgTab;
}

int Swiat::porownajSile(Organizm* org1, Organizm* org2)
{
    if (org1->getSila() > org2->getSila()) return 1;
    else if (org1->getSila() == org2->getSila()) return 0;
    else return -1;
}