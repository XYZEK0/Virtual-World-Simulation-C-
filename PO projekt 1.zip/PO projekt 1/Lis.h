#pragma once
#include "Zwierze.h"

class Lis :public Zwierze
{
public:
	Lis(Vector* pos, Swiat* world);
	void akcja(Swiat* swiat) override;
	void kolizja(Swiat* swiat, Organizm* org) override;
};