#include "Czlowiek.h"
#include "Swiat.h"

Czlowiek::Czlowiek(Vector* pos, Swiat* sw) : Zwierze(5, 4, pos, 'P', sw)
{
	this->isPowerOn = false;
	this->isPowerOnCooldown = false;
	this->cooldownTurns = 0;
	this->powerTurns = 0;
	this->moveDistance = 1;
}

void Czlowiek::akcja(Swiat* swiat)
{
	if (powerTurns > 2) moveDistance = 2;
	else if (powerTurns != 0 && (rand() & 4) > 1)
	{
		moveDistance = 2;
	}
	else moveDistance = 1;

	cout << "Power status: " << this->isPowerOn << endl;
	if (this->cooldownTurns > 0 && this->isPowerOnCooldown)
	{
		this->cooldownTurns--;
		cout << "Power is on cooldown for: " << this->cooldownTurns << " turns" << endl;
	}
	else
	{
		if (this->powerTurns > 0)
		{
			this->powerTurns--;
			if (this->powerTurns == 0)
			{
				this->cooldownTurns = 5;
				this->isPowerOn = false;
				this->isPowerOnCooldown = true;
			}
		}
	}
	
	if (this->isPowerOn) cout << "Moc gracza aktywna!" << endl;
	cout << "Sila czlowieka: " << this->getSila() << endl;
	this->setCanMove(true);
	oldPos = pos;


	char input;
	std::cin >> input;
	system("cls");
	Vector* destination = NULL;
	switch (input)
	{
		if (input == 'p' && this->isPowerOn) break;

		case 'w': destination = new Vector(this->pos->getX(),this->pos->getY() - moveDistance ); break;
		case 's': destination = new Vector(this->pos->getX(), this->pos->getY() + moveDistance); break;
		case 'a': destination = new Vector(this->pos->getX() - moveDistance, this->pos->getY()); break;
		case 'd': destination = new Vector(this->pos->getX() + moveDistance, this->pos->getY()); break;
		case 'p': this->isPowerOn = true; this->powerTurns = 5; break;
		default: break;
	}
	
	if (destination != NULL)
	{
		if (swiat->getOrganizmy()[destination->getY()][destination->getX()] != NULL)
		{
			swiat->getOrganizmy()[destination->getY()][destination->getX()]->kolizja(swiat, this);
		}

		if (this->getCanMove())
			this->setPos(destination);
	}
	//system("cls");
	
	//this->Zwierze::akcja(swiat);
	
}

void Czlowiek::kolizja(Swiat*swiat, Organizm* zwierze)
{
	
	std::cout << "Kolizja Czlowieka z " << zwierze->getZnak() << std::endl;
	this->Organizm::walka(swiat, zwierze);
	
}