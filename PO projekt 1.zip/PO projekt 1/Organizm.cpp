#include "Organizm.h"
#include "Swiat.h"


Organizm::Organizm(int si, int ini,Vector*vec, char znak, Swiat* sw)
{
	this->sila = si;
	this->inicjatywa = ini;
	this->pos = vec;
	this->swiat = sw;
	this->znak = znak;
	this->czyZyje = true;
	this->canMove = true;
	this->wiek = 0;
	this->oldPos = vec;

}

void Organizm::walka(Swiat* swiat, Organizm*org)
{
	vector<Organizm*>temp;
	vector<Organizm*>temp1;
	
	if (swiat->porownajSile(this,org) == 1)
	{
		cout << this->getZnak() << " zabija " << org->getZnak() << endl;

		swiat->getOrganizmy()[org->getPos()->getY()][org->getPos()->getX()] = NULL;
		 temp = swiat->getVector();
		 temp1 = swiat->getVectorZywe();
		for (int i = 0; i < temp1.size(); i++)
		{
			if (temp1[i] == org) temp1.erase(temp1.begin() + i);
		}
		for (int i = 0; i < temp.size(); i++)
		{
			if (temp[i] == org) temp.erase(temp.begin() + i);
		}
	}
	else
	{
		cout << org->getZnak() << " zabija " << this->getZnak()  << endl;
		swiat->getOrganizmy()[this->getPos()->getY()][this->getPos()->getX()] = NULL;
		 temp = swiat->getVector();
		 temp1 = swiat->getVectorZywe();
		for (int i = 0; i < temp1.size(); i++)
		{
		 if (temp1[i] == this) temp1.erase(temp1.begin() + i);
		}
		for (int i = 0; i < temp.size(); i++)
		{
			if (temp[i] == this) temp.erase(temp.begin() + i);
		}
	}
	swiat->setVector(temp);
	swiat->setVectorZywe(temp1);
	
}