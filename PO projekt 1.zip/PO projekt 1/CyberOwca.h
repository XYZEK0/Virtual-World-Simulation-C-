#pragma once
#include "Zwierze.h"

class CyberOwca :public Zwierze
{
	public:
	CyberOwca(Vector* pos, Swiat* world);
	void akcja(Swiat* swiat) override;
	void kolizja(Swiat* swiat, Organizm* org) override;
private:
	Vector* okreslVectordoBarszczu(Swiat*swiat);
	Organizm* findClosestBaszcz(Swiat* swiat);
};