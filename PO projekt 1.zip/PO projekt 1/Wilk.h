#pragma once
#include "Zwierze.h"
#include <iostream>

class Wilk : public Zwierze
{
public:
	Wilk(Vector*pos, Swiat* sw);

	void akcja(Swiat* swiat) override;
	void kolizja(Swiat* swiat, Organizm* org) override;
};