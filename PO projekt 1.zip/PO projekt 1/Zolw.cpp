#include "Zolw.h"
#include "Vector.h"
#include "Swiat.h"
#include <iostream>
#include <time.h>

Zolw::Zolw(Vector* pos, Swiat* sw) :Zwierze(2, 1, pos, 'Z', sw)
{
	;
}

void Zolw::akcja(Swiat* swiat)
{

	this->setCanMove(true);
	
	int move = rand() % 4;
	
	if (move == 3)
	{
		this->Zwierze::akcja(swiat);
	}
	//else std::cout << this->pos->getX() << " " << this->pos->getY() << " ";
	//std::cout << "Akcja zolwia!" << std::endl;
}

void Zolw::kolizja(Swiat* swiat, Organizm* org)
{
	if (this->getZnak() == org->getZnak())
	{
		org->setCanMove(false);
		this->Zwierze::kolizja(swiat, org);
	}
	else
	{
		std::cout << "Kolizja Zolw z " << org->getZnak() << std::endl;
		if (org->getSila() < 5)
		{
			cout << "Zolw odpiera atak " << org->getZnak() << endl;
			org->setCanMove(false);
		}
		else this->Organizm::walka(swiat, org);
	}
}