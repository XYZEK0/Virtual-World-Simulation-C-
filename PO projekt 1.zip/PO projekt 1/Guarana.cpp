#include "Guarana.h"
#include <iostream>
#include "Zwierze.h"
Guarana::Guarana(Vector* pos, Swiat* world) : Roslina(0,0,pos,'G',world)
{

}

void Guarana::akcja(Swiat* swiat)
{
	//std::cout << this->pos->getX() << " " << this->pos->getY() << " ";
	//std::cout << "Akcja Guarana!" << std::endl;
	int number = rand() % 5;
	if (number == 0)
		this->Roslina::akcja(swiat);
}

void Guarana::kolizja(Swiat* swiat,Organizm*org)
{
	org->setSila(org->getSila() + 3);
	std::cout << "Kolizja Guarana z " << org->getZnak() << std::endl;
	this->Organizm::walka(swiat, org);
}
