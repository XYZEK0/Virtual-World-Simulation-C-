#include "Vector.h"
#include <math.h>

bool Vector::operator == (Vector* v)
{
	return (this->x == v->getX() && this->y == v->getY());
}

Vector* Vector::operator = (Vector* v)
{
	this->x = v->getX();
	this->y = v->getY();
	return (this);
}

int Vector::returnLength(Vector*vec)
{
	return pow(pow(abs(vec->getX()), 2) + pow(abs(vec->getY()), 2), 0.5);
}