#include "WilczeJagody.h"
#include <iostream>
WilczeJagody::WilczeJagody(Vector* pos, Swiat* sw) : Roslina(99, 0, pos,'J', sw)
{
	;
}

void WilczeJagody::akcja(Swiat* swiat)
{
	//std::cout << this->pos->getX() << " " << this->pos->getY() << " ";
	//std::cout << "Akcja WilczeJagody!" << std::endl;
	int number = rand() % 5;
	if (number == 0)
		this->Roslina::akcja(swiat);
}

void WilczeJagody::kolizja(Swiat* swiat, Organizm* org)
{
	std::cout << "Kolizja WilczeJagody z " << org->getZnak() << std::endl;
	this->Organizm::walka(swiat, org);
}