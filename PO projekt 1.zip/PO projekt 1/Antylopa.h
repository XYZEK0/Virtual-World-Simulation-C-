#pragma once
#include "Zwierze.h"

class Antylopa :public Zwierze
{
	public:
	Antylopa(Vector* pos, Swiat* world);
	void akcja(Swiat* swiat) override;
	void kolizja(Swiat* swiat, Organizm* org) override;
};