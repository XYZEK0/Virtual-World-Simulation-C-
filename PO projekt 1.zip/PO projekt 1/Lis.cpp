#include "Lis.h"
#include <iostream>
#include <time.h>
#include "Swiat.h"

Lis::Lis(Vector* pos, Swiat* sw) : Zwierze(3, 7, pos, 'L', sw)
{
	;
}

void Lis::akcja(Swiat* swiat)
{
	//std::cout << this->pos->getX() << " " << this->pos->getY() << " ";
	//std::cout << "Akcja Lisa!" << std::endl;
	this->setCanMove(true);
	oldPos = pos;
	int number;
	bool hasMoved = false;
	bool shouldBreak = false;
	Vector* destination = NULL;
	
	vector<int>forbiddenFields;
	while (!hasMoved)
	{
		if (forbiddenFields.size() >= 4) return;
		shouldBreak = false;
		number = rand() % 4;
		switch (number)
		{
			for (int i = 0; i < forbiddenFields.size(); i++)
			{
				if (number == forbiddenFields[i]) shouldBreak = true;
			}
			if (shouldBreak) break;
			case 0: 
				if (this->pos->getY() - 1 > 1)
				{ 
					if (swiat->getOrganizmy()[this->pos->getY()][this->pos->getX() - 1] != NULL)
					{
						if (swiat->porownajSile(this, swiat->getOrganizmy()[this->pos->getY()][this->pos->getX() - 1]) > 0   && this->pos->getY() - 1 > 0)
						{
							destination = new Vector(this->getPos()->getX() - 1, this->getPos()->getY());
							hasMoved = true;
						}
						else
						{
							hasMoved = false;
							forbiddenFields.push_back(0);
						}
					}
					else 
					{
						destination = new Vector(this->getPos()->getX() - 1, this->getPos()->getY() );
						hasMoved = true;
					}
				}
				break;
			case 1: 
				if (this->pos->getY() < swiat->getSizeY() - 2)
				{ 
					if (swiat->getOrganizmy()[this->pos->getY()][this->pos->getX() + 1] != NULL)
					{
						if (swiat->porownajSile(this, swiat->getOrganizmy()[this->pos->getY()][this->pos->getX() + 1]) > 0   && this->pos->getY() < swiat->getSizeY() - 1)
						{
							destination = new Vector(this->getPos()->getX() + 1, this->getPos()->getY() );
							hasMoved = true;
						}
						else
						{
							hasMoved = false;
							forbiddenFields.push_back(1);
						}
					}
					else 
					{
						destination = new Vector(this->getPos()->getX() + 1, this->getPos()->getY() );
						hasMoved = true;
					}
				}
				  break;
			case 2:
				if (this->pos->getX() > 1)
				{
					if (swiat->getOrganizmy()[this->pos->getY() - 1][this->pos->getX()] != NULL)
					{
						if (swiat->porownajSile(this, swiat->getOrganizmy()[this->pos->getY() - 1][this->pos->getX()]) > 0 && this->pos->getX() > 0)
						{
							destination = new Vector(this->getPos()->getX(), this->getPos()->getY()-1);
							hasMoved = true;
						}
						else
						{
							hasMoved = false;
							forbiddenFields.push_back(2);
						}
					}
					else
					{
						destination = new Vector(this->getPos()->getX() , this->getPos()->getY() - 1);
						hasMoved = true;
					}
				}
				 break;
			case 3: 
				if (this->pos->getX() < swiat->getSizeX() - 2)
				{
					if (swiat->getOrganizmy()[this->pos->getY() + 1][this->pos->getX()] != NULL)
					{
						if (swiat->porownajSile(this, swiat->getOrganizmy()[this->pos->getY() + 1][this->pos->getX()]) > 0 && this->pos->getX() < swiat->getSizeX() - 1)
						{
							destination = new Vector(this->getPos()->getX() , this->getPos()->getY() + 1);
							hasMoved = true;
						}
						else
						{
							hasMoved = false;
							forbiddenFields.push_back(3);
						}
					}
					else
					{
						destination = new Vector(this->getPos()->getX() , this->getPos()->getY() + 1);
						hasMoved = true;
					}
				}
				 break;
			default: std::cout << "Blad w ruchu!" << std::endl; break;
		}
	}
	if (swiat->getOrganizmy()[destination->getY()][destination->getX()] != NULL)
	{
		swiat->getOrganizmy()[destination->getY()][destination->getX()]->kolizja(swiat, this);
	}
	if (this->getCanMove())
	this->setPos(destination);
	
}

void Lis::kolizja(Swiat* swiat, Organizm* org)
{
	if (this->getZnak() == org->getZnak())
	{
		org->setCanMove(false);
		this->Zwierze::kolizja(swiat, org);
	}
	else
	{
		std::cout << "Kolizja Lis z " << org->getZnak() << std::endl;
		this->Organizm::walka(swiat, org);
	}
}