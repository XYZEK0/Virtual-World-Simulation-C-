#include "Wilk.h"

using namespace std;

Wilk::Wilk(Vector* pos, Swiat* sw) : Zwierze(9,5, pos,'W', sw)
{
	;
}

void Wilk::akcja(Swiat* swiat)
{
	this->Zwierze::akcja(swiat);
	//cout << "Akcja Wilka" << endl;
	
}

void Wilk::kolizja(Swiat* swiat, Organizm* org)
{
	//std::cout << this->pos->getX() << " " << this->pos->getY() << " ";
	//std::cout << "Akcja Wilka!" << std::endl;
	if (this->getZnak() == org->getZnak())
	{
		org->setCanMove(false);
		this->Zwierze::kolizja(swiat, org);
	}
	else
	{
		std::cout << "Kolizja Wilk z " << org->getZnak() << std::endl;
		this->Organizm::walka(swiat, org);
	}
}