#include "Zwierze.h"
#include "Swiat.h"
#include <iostream>
#include <time.h>

using namespace std;

Zwierze::Zwierze(int si, int ini, Vector* pos, char znak, Swiat* sw) : Organizm(si, ini, pos, znak, sw)
{
	;
}

void Zwierze::akcja(Swiat* swiat)
{
	oldPos = pos;
	this->setCanMove(true);
	
	int number;
	bool hasMoved = false;

	Vector* destination = NULL;
	while (!hasMoved)
	{
		

		number = rand() % 4;
		switch (number)
		{
		case 0:
			if (this->pos->getY() - 1 > 0)
			{
				destination = new Vector(this->getPos()->getX(), this->getPos()->getY() - 1);
				hasMoved = true;
			}
			break;
		case 1:
			if (this->pos->getY() + 1 < swiat->getSizeY() - 1)
			{
				destination = new Vector(this->getPos()->getX(), this->getPos()->getY() + 1);
				hasMoved = true;
			}
			break;
		case 2:
			if (this->pos->getX() - 1 > 0)
			{
				destination = new Vector(this->getPos()->getX() - 1, this->getPos()->getY());
				hasMoved = true;
			}
			break;
		case 3:
			if (this->pos->getX() + 1 < swiat->getSizeX() - 1)
			{
				destination = new Vector(this->getPos()->getX() + 1, this->getPos()->getY());
				hasMoved = true;
			}
			break;
		default: std::cout << "Blad w ruchu!" << endl; break;
		}
	}

	if (swiat->getOrganizmy()[destination->getY()][destination->getX()] != NULL)
	{
		swiat->getOrganizmy()[destination->getY()][destination->getX()]->kolizja(swiat, this);
	}
	if (this->getCanMove())
		this->setPos(destination);
}

void Zwierze::kolizja(Swiat* swiat, Organizm* zwierze)
{
	
	vector<Organizm*>temp1;
	Vector* position = NULL;
	
	if (swiat->getOrganizmy()[this->getPos()->getY() + 1][this->getPos()->getX()] == NULL && swiat->getPlansza()[this->getPos()->getY() + 1][this->getPos()->getX()] == ' ')
	{
		position = new Vector(this->getPos()->getX(), this->getPos()->getY() + 1);
	}
	else if (swiat->getOrganizmy()[this->getPos()->getY() - 1][this->getPos()->getX()]  == NULL && swiat->getPlansza()[this->getPos()->getY() - 1][this->getPos()->getX()] == ' ')
	{
		position = new Vector(this->getPos()->getX(), this->getPos()->getY() - 1);
	}
	else if (swiat->getOrganizmy()[this->getPos()->getY() + 1][this->getPos()->getX() - 1] == NULL && swiat->getPlansza()[this->getPos()->getY() + 1][this->getPos()->getX() - 1] == ' ')
	{
		position = new Vector(this->getPos()->getX() - 1, this->getPos()->getY() + 1);
	}
	else if (swiat->getOrganizmy()[this->getPos()->getY() + 1][this->getPos()->getX() + 1] == NULL && swiat->getPlansza()[this->getPos()->getY() + 1][this->getPos()->getX() + 1] == ' ')
	{
		position = new Vector(this->getPos()->getX() + 1, this->getPos()->getY() + 1);
	}
	else if (swiat->getOrganizmy()[this->getPos()->getY() ][this->getPos()->getX() + 1] == NULL && swiat->getPlansza()[this->getPos()->getY()][this->getPos()->getX() + 1] == ' ')
	{
		position = new Vector(this->getPos()->getX() + 1, this->getPos()->getY());
	}
	else if (swiat->getOrganizmy()[this->getPos()->getY()][this->getPos()->getX() - 1] == NULL && swiat->getPlansza()[this->getPos()->getY()][this->getPos()->getX() - 1] == ' ')
	{
		position = new Vector(this->getPos()->getX() - 1, this->getPos()->getY());
	}
	else if (swiat->getOrganizmy()[this->getPos()->getY() - 1][this->getPos()->getX() + 1] == NULL && swiat->getPlansza()[this->getPos()->getY() - 1][this->getPos()->getX() + 1] == ' ')
	{
		position = new Vector(this->getPos()->getX() + 1, this->getPos()->getY() - 1);
	}
	else if (swiat->getOrganizmy()[this->getPos()->getY() - 1][this->getPos()->getX() - 1] == NULL && swiat->getPlansza()[this->getPos()->getY() - 1][this->getPos()->getX() - 1] == ' ')
	{
		position = new Vector(this->getPos()->getX() - 1, this->getPos()->getY() - 1);
	}

	if (position == NULL) return;

	Organizm* zw = NULL;
	if (dynamic_cast<Owca*>(this) != nullptr)  zw = new Owca(position,swiat);
	else if (dynamic_cast<Antylopa*>(this) != nullptr)  zw = new Antylopa(position, swiat);
	else if (dynamic_cast<Lis*>(this) != nullptr) zw = new Lis(position, swiat);
	else if (dynamic_cast<Zolw*>(this) != nullptr) zw = new Zolw(position, swiat);
	else if (dynamic_cast<Wilk*>(this) != nullptr) zw = new Wilk(position, swiat);

	

	swiat->getOrganizmy()[position->getY()][position->getX()] = zw;
	
	temp1 = swiat->getVectorZywe();
	temp1.push_back(zw);
	swiat->sortujOrganizmy(temp1, 0, temp1.size() - 1);
	swiat->setVectorZywe(temp1);
}

void Zwierze::rysowanie()
{
	cout << "Rysowanie Zwierze!";
}

