#pragma once
#include "Roslina.h"

class Guarana :public Roslina
{
public:
	Guarana(Vector* pos, Swiat* world);
	void akcja(Swiat* swiat) override;
	void kolizja(Swiat* swiat, Organizm* org) override;
};