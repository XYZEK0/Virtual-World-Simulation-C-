#pragma once

#include "Roslina.h"

class WilczeJagody :public Roslina
{
	public:
	WilczeJagody(Vector* pos, Swiat* world);
	void akcja(Swiat* swiat) override;
	void kolizja(Swiat* swiat, Organizm* org) override;
};