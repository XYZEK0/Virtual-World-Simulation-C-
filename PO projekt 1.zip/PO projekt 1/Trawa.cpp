#include "Trawa.h"
#include <iostream>

Trawa::Trawa(Vector* pos, Swiat* sw) : Roslina(0,0,pos, 'T', sw)
{
	;
}

void Trawa::akcja(Swiat* swiat)
{
	//std::cout << this->pos->getX() << " " << this->pos->getY() << " ";
	//std::cout << "Akcja Trawy!" << std::endl;

	int number = rand() % 5;
	if(number == 0)
	this->Roslina::akcja(swiat);
}

void Trawa::kolizja(Swiat* swiat, Organizm* org)
{
	std::cout << "Kolizja Trawa z " << org->getZnak() << std::endl;
	this->Organizm::walka(swiat, org);
}