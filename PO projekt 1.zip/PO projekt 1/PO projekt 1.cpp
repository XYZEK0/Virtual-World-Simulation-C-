﻿#include "Swiat.h"
#include "Organizm.h"
#include "Zwierze.h"
#include "Wilk.h"
#include "Vector.h"
#include <iostream>
#include <time.h>

using namespace std;

void menu();


int main()
{
    srand(time(NULL));
    menu();
    return 0;
}

void menu()
{
    int sizeX = 20;
    int sizeY = 20;
    

    Swiat* world = new Swiat(sizeX,sizeY);
    
}


