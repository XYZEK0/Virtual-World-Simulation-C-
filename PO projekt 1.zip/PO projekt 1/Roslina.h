#pragma once
#include "Organizm.h"


class Roslina :public Organizm
{
	public:
		Roslina(int sila,int ini, Vector* pos, char znak, Swiat* sw);
	    
	void akcja(Swiat* swiat) override;
	

	
	void kolizja(Swiat*swiat,Organizm* zwierze) override
	{

	}
	void rysowanie() override
	{

	}

};
