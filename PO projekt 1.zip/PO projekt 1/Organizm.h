#pragma once
#include <iostream>
#include "Vector.h"
class Swiat;
class Organizm
{
protected:
	int sila;
	int inicjatywa;
	int wiek;
	Vector* pos;
	Vector* oldPos;
	char znak;
	bool czyZyje;
	bool canMove;
	Swiat* swiat;
public:
	Organizm(int si, int ini, Vector*vec, char znak, Swiat* sw);

	int getSila()
	{
		return this->sila;
	}
	int getInicjatywa()
	{
		return this->inicjatywa;
	}
	int getWiek()
	{
		return this->wiek;
	}
	Vector* getPos()
	{
		return this->pos;
	}
	Vector* getoldPos()
	{
		return this->oldPos;
	}
	char getZnak()
	{
		return this->znak;
	}
	bool getCzyZyje()
	{
		return this->czyZyje;
	}
	bool getCanMove()
	{
		return this->canMove;
	}
	Swiat* getSwiat()
	{
		return this->swiat;
	}

	
	void setSila(int value)
	{
		this->sila = value;
	}
	void setInicjatywa(int value)
	{
		this->inicjatywa = value;
	}
	void setWiek(int value)
	{
		this->wiek = value;
	}
	void setPos(Vector* pos)
	{
		this->pos = pos;
	}
	void setZnak(char znak)
	{
		this->znak = znak;
	}
	void setZycie(bool value)
	{
		this->czyZyje = value;
	}
	void setSwiat(Swiat* sw)
	{
		this->swiat = sw;
	}
	void setoldPos(Vector* pos)
	{
		this->oldPos = pos;
	}
	void setCanMove(bool value)
	{
		this->canMove = value;
	}

	virtual void akcja(Swiat* swiat) = 0;
	virtual void kolizja(Swiat*swiat, Organizm* zwierze) = 0;
	virtual void rysowanie() = 0;
	void walka(Swiat* swiat, Organizm* org);
	
};