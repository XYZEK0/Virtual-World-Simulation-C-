#pragma once
#include <time.h>
#include "Organizm.h"
#include "Wilk.h"
#include "Owca.h"
#include "Lis.h"
#include "Zolw.h"
#include "Antylopa.h"
#include "CyberOwca.h"
#include "Trawa.h"
#include "Mlecz.h"
#include "Guarana.h"
#include "WilczeJagody.h"
#include "Barszcz.h"
#include "Czlowiek.h"
#include <vector>

using namespace std;
class Swiat
{
	
	private:
	bool czyGraczZyje;
	char** plansza;
	Organizm*** organizmy;
	vector<Organizm*>orgTab;
	vector<Organizm*>zyweOrg;
	int sizeOrganizmy2D;
	int sizeX;
	int sizeY;
	public:
		Swiat(int sizeX, int sizeY)
		{
			this->sizeX = sizeX;
			this->sizeY = sizeY;

			plansza = new char* [this->sizeX];

			for (int i = 0; i < this->sizeX; i++)
			{
				plansza[i] = new char[this->sizeY];
			}

			organizmy = new Organizm * *[sizeX];

			for (int i = 0; i < sizeX; i++)
			{
				organizmy[i] = new Organizm * [sizeY];
			}
			for (int i = 0; i < sizeX; i++)
			{
				for (int j = 0; j < sizeY; j++)
				{
					organizmy[i][j] = NULL;
				}
			}
			
			this->czyGraczZyje = true;
			
			Organizm* org;
		
			
			org = new Owca(new Vector(5, 6), this);
			organizmy[org->getPos()->getY()][org->getPos()->getX()] = org;
			
			org = new Owca(new Vector(5, 7), this);
			organizmy[org->getPos()->getY()][org->getPos()->getX()] = org;
			
			org = new Owca(new Vector(5, 8), this);
			organizmy[org->getPos()->getY()][org->getPos()->getX()] = org;
			
			org = new Wilk(new Vector(10, 5), this);
			organizmy[org->getPos()->getY()][org->getPos()->getX()] = org;
			org = new Wilk(new Vector(10, 10), this);
			organizmy[org->getPos()->getY()][org->getPos()->getX()] = org;
			org = new Wilk(new Vector(10, 7), this);
			organizmy[org->getPos()->getY()][org->getPos()->getX()] = org;
			
			org = new Zolw(new Vector(7, 15), this);
			organizmy[org->getPos()->getY()][org->getPos()->getX()] = org;
			
			org = new Antylopa(new Vector(5, 14), this);
			organizmy[org->getPos()->getY()][org->getPos()->getX()] = org;
			
			org = new CyberOwca(new Vector(5, 2), this);
			organizmy[org->getPos()->getY()][org->getPos()->getX()] = org;
			
			org = new Trawa(new Vector(18, 8), this);
			organizmy[org->getPos()->getY()][org->getPos()->getX()] = org;
			
			org = new Guarana(new Vector(13, 5), this);
			organizmy[org->getPos()->getY()][org->getPos()->getX()] = org;
			
			org = new Mlecz(new Vector(9, 7), this);
			organizmy[org->getPos()->getY()][org->getPos()->getX()] = org;
			org = new Mlecz(new Vector(16, 17), this);
			organizmy[org->getPos()->getY()][org->getPos()->getX()] = org;
			
			org = new WilczeJagody(new Vector(6, 16), this);
			organizmy[org->getPos()->getY()][org->getPos()->getX()] = org;
			
			org = new Barszcz(new Vector(18, 18), this);
			organizmy[org->getPos()->getY()][org->getPos()->getX()] = org;
			org = new Barszcz(new Vector(2, 2), this);
			organizmy[org->getPos()->getY()][org->getPos()->getX()] = org;
			org = new Barszcz(new Vector(7, 7), this);
			organizmy[org->getPos()->getY()][org->getPos()->getX()] = org;
			
			org = new Lis(new Vector(12, 3), this);
			organizmy[org->getPos()->getY()][org->getPos()->getX()] = org;
		
			org = new Lis(new Vector(12, 6), this);
			organizmy[org->getPos()->getY()][org->getPos()->getX()] = org;

			
			
			org = new Czlowiek(new Vector(5, 5), this);
			organizmy[org->getPos()->getY()][org->getPos()->getX()] = org;
			
			rysujSwiat(this);
		}

	void wykonajTure();
	void rysujSwiat(Swiat* worldInstance);
	void zaktualizujWiek();
	void sortujOrganizmy(vector<Organizm*>& organizmy, int first, int last);
	void swap(Organizm*& org1, Organizm*& org2);
	void countOrganizmy3D(Organizm*** organizmy);
	vector<Organizm*> makeOrganizmyTab(Organizm***organizmy);
	Organizm* findOrganizm(Swiat* worldInstance, char orgChar);
	
	int partycja(vector<Organizm*>& organizmy, int first, int last);
	int porownajSile(Organizm* org1, Organizm* org2);
	bool sprawdzCzyGraczZyje();


	void setPlansza(char** plansza)
	{
		this->plansza = plansza;
	}
	void setOrganizmy(Organizm*** organizm)
	{
		this->organizmy = organizm;
	}
	void setsizeOrganizmy2D(int size)
	{
		this->sizeOrganizmy2D = size;
	}
	void setVector(vector<Organizm*> vector)
	{
		this->orgTab = vector;
	}
	void setVectorZywe(vector<Organizm*> vector)
	{
		this->zyweOrg = vector;
	}

	Organizm*** getOrganizmy()
	{
		return organizmy;
	}
	vector<Organizm*>&getVector()
	{
		return this->orgTab;
	}
	vector<Organizm*>& getVectorZywe()
	{
		return this->zyweOrg;
	}
	int getSizeX()
	{
		return sizeX;
	}
	int getSizeY()
	{
		return sizeY;
	}
	int getsizeOrganizmy2D()
	{
		return this->sizeOrganizmy2D;
	}
	char** getPlansza()
	{
		return plansza;
	}
	
};