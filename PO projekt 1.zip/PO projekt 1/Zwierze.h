#pragma once
#include "Organizm.h"
#include <iostream>

class Zwierze : public Organizm
{

public:
	Zwierze(int si, int ini, Vector* pos, char znak, Swiat* sw);
	void akcja(Swiat* swiat) override;
	void kolizja(Swiat* swiat,Organizm* zwierze) override;
	void rysowanie() override;
	
};