#include "Owca.h"
#include <iostream>
#include "Swiat.h"
Owca::Owca(Vector* pos, Swiat* sw) : Zwierze(4, 4, pos, 'O', sw)
{
	;
}

void Owca::akcja(Swiat* swiat)
{
	//std::cout << this->pos->getX() << " " << this->pos->getY() << " ";
	//std::cout << "Akcja Owca!" << std::endl;
	this->Zwierze::akcja(swiat);
}

void Owca::kolizja(Swiat* swiat, Organizm* org)
{
	if (this->getZnak() == org->getZnak())
	{
		org->setCanMove(false);
		this->Zwierze::kolizja(swiat, org);
	}
	else
	{
		std::cout << "Kolizja Owca z " << org->getZnak() << " ";
		this->Organizm::walka(swiat, org);
	}
}

