#pragma once
#include "Roslina.h"


class Barszcz :public Roslina
{
	public:
	Barszcz(Vector* pos, Swiat* world);
	void akcja(Swiat* swiat) override;
	void kolizja(Swiat* swiat, Organizm* org) override;
	private:
	void eksterminacja(Swiat* swiat);
};