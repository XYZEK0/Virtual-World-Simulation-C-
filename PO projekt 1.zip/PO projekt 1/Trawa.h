#pragma once
#include "Roslina.h"

class Trawa :public Roslina
{
public:
	Trawa(Vector* pos, Swiat* world);
	void akcja(Swiat* swiat) override;
	void kolizja(Swiat* swiat, Organizm* org) override;
};