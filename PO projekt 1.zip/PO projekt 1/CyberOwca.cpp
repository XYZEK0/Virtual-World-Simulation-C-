#include "CyberOwca.h"
#include <iostream>
#include "Vector.h"
#include "Swiat.h"
#include <math.h>

CyberOwca::CyberOwca(Vector*pos, Swiat*sw) :Zwierze(11,4,pos,'C',sw)
{
	;
}

void CyberOwca::akcja(Swiat* swiat)
{
	//std::cout << this->pos->getX() << " " << this->pos->getY() << " ";
	//std::cout << "Akcja CyberOwca!" << std::endl;
	this->setCanMove(true);
	oldPos = pos;
	Vector* destiny = okreslVectordoBarszczu(swiat);
	Vector* move = NULL;
	if (destiny == NULL) this->Zwierze::akcja(swiat);
	else
	{
		if ((destiny->getX() - this->getPos()->getX()) > 0)
			move = new Vector(this->getPos()->getX() + 1, this->getPos()->getY());

		else if ((destiny->getX() - this->getPos()->getX()) < 0)
			move = new Vector(this->getPos()->getX() - 1, this->getPos()->getY());
		else
		{
			if ((destiny->getY() - this->getPos()->getY()) > 0)
				move = new Vector(this->getPos()->getX(), this->getPos()->getY() + 1);
			else if ((destiny->getY() - this->getPos()->getY()) < 0)
				move = new Vector(this->getPos()->getX(), this->getPos()->getY() - 1);
			
		}
	}
	
	if(move!=NULL)
	{ 
		if (swiat->getOrganizmy()[move->getY()][move->getX()] != NULL)
		{										
			swiat->getOrganizmy()[move->getY()][move->getX()]->kolizja(swiat, this);
		}
	}
	if(move!=NULL && this->getCanMove())
	this->setPos(move);
	//std::cout << "Akcja CyberOwcy!" << std::endl;
}

void CyberOwca::kolizja(Swiat* swiat, Organizm* org)
{
	std::cout << "Kolizja CyberOwca z " << org->getZnak() << std::endl;
	this->Organizm::walka(swiat, org);
}

Vector* CyberOwca::okreslVectordoBarszczu(Swiat*swiat)
{
	Organizm* barszcz = findClosestBaszcz(swiat);
	if (barszcz != NULL)
		return barszcz->getPos();
	else return NULL;
}

Organizm*CyberOwca:: findClosestBaszcz(Swiat* swiat)
{
	int size = 0;
	for (int i = 0; i < swiat->getSizeX(); i++)
	{
		for (int j = 0; j < swiat->getSizeY(); j++)
		{
			if(swiat->getOrganizmy()[i][j]!=NULL)
			{
				if (swiat->getOrganizmy()[i][j]->getZnak() == 'X')
					size++;
			}
		}
	}

	if (size == 0) return NULL;
	Organizm** barszcze = new Organizm*[size];
	
	int iterator = 0;
	for (int i = 0; i < swiat->getSizeX(); i++)
	{
		for (int j = 0; j < swiat->getSizeY(); j++)
		{
			if (swiat->getOrganizmy()[i][j] != NULL)
			{
				if (swiat->getOrganizmy()[i][j]->getZnak() == 'X')
				{
					barszcze[iterator] = swiat->getOrganizmy()[i][j];
					iterator++;
				}
			}
		}
	}

	Organizm* smallestDistance = barszcze[0];
	for (int i = 1; i < size; i++)
	{
		if (barszcze[i]->getPos()->returnLength(barszcze[i]->getPos()) > smallestDistance->getPos()->returnLength(smallestDistance->getPos()))
			smallestDistance = barszcze[i];
	}

	return smallestDistance;
}