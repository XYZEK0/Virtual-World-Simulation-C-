#pragma once
class Vector
{
private:
	int x = 0;
	int y = 0;

public:

	int getX()
	{
		return x;
	}
	int getY()
	{
		return y;
	}
	void setX(int x)
	{
		this->x = x;
	}
	void setY(int y)
	{
		this->y = y;
	}

	Vector(int x, int y)
	{
		this->x = x;
		this->y = y;
	}
	Vector()
	{
		
	}
	int returnLength(Vector* vec);
	bool operator == (Vector* v);
	Vector* operator = (Vector* v);
};	