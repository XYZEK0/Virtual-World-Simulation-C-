#include "Roslina.h"
#include <iostream>
#include <vector>
#include "Swiat.h"
using namespace std;

Roslina::Roslina(int sila, int ini, Vector* pos, char znak, Swiat* sw) : Organizm(sila, ini, pos, znak, sw)
{
	;
}

void Roslina::akcja(Swiat*swiat) 
{
	vector<Organizm*>temp1;
	Vector* position = NULL;

	if (swiat->getOrganizmy()[this->getPos()->getY() + 1][this->getPos()->getX()] == NULL && swiat->getPlansza()[this->getPos()->getY() + 1][this->getPos()->getX()] == ' ')
	{
		position = new Vector(this->getPos()->getX(), this->getPos()->getY() + 1);
	}
	else if (swiat->getOrganizmy()[this->getPos()->getY() - 1][this->getPos()->getX()] == NULL && swiat->getPlansza()[this->getPos()->getY() - 1][this->getPos()->getX()] == ' ')
	{
		position = new Vector(this->getPos()->getX(), this->getPos()->getY() - 1);
	}
	else if (swiat->getOrganizmy()[this->getPos()->getY() + 1][this->getPos()->getX() - 1] == NULL && swiat->getPlansza()[this->getPos()->getY() + 1][this->getPos()->getX() - 1] == ' ')
	{
		position = new Vector(this->getPos()->getX() - 1, this->getPos()->getY() + 1);
	}
	else if (swiat->getOrganizmy()[this->getPos()->getY() + 1][this->getPos()->getX() + 1] == NULL && swiat->getPlansza()[this->getPos()->getY() + 1][this->getPos()->getX() + 1] == ' ')
	{
		position = new Vector(this->getPos()->getX() + 1, this->getPos()->getY() + 1);
	}
	else if (swiat->getOrganizmy()[this->getPos()->getY()][this->getPos()->getX() + 1] == NULL && swiat->getPlansza()[this->getPos()->getY()][this->getPos()->getX() + 1] == ' ')
	{
		position = new Vector(this->getPos()->getX() + 1, this->getPos()->getY());
	}
	else if (swiat->getOrganizmy()[this->getPos()->getY()][this->getPos()->getX() - 1] == NULL && swiat->getPlansza()[this->getPos()->getY()][this->getPos()->getX() - 1] == ' ')
	{
		position = new Vector(this->getPos()->getX() - 1, this->getPos()->getY());
	}
	else if (swiat->getOrganizmy()[this->getPos()->getY() - 1][this->getPos()->getX() + 1] == NULL && swiat->getPlansza()[this->getPos()->getY() - 1][this->getPos()->getX() + 1] == ' ')
	{
		position = new Vector(this->getPos()->getX() + 1, this->getPos()->getY() - 1);
	}
	else if (swiat->getOrganizmy()[this->getPos()->getY() - 1][this->getPos()->getX() - 1] == NULL && swiat->getPlansza()[this->getPos()->getY() - 1][this->getPos()->getX() - 1] == ' ')
	{
		position = new Vector(this->getPos()->getX() - 1, this->getPos()->getY() - 1);
	}

	if (position == NULL) return;

	Organizm* zw = NULL;
	if (dynamic_cast<Trawa*>(this) != nullptr)  zw = new Trawa(position, swiat);
	else if (dynamic_cast<Mlecz*>(this) != nullptr)  zw = new Mlecz(position, swiat);
	else if (dynamic_cast<Guarana*>(this) != nullptr) zw = new Guarana(position, swiat);
	else if (dynamic_cast<WilczeJagody*>(this) != nullptr) zw = new WilczeJagody(position, swiat);
	else if (dynamic_cast<Barszcz*>(this) != nullptr) zw = new Barszcz(position, swiat);

	swiat->getOrganizmy()[position->getY()][position->getX()] = zw;

	temp1 = swiat->getVectorZywe();
	temp1.push_back(zw);
	swiat->sortujOrganizmy(temp1, 0, temp1.size() - 1);
	swiat->setVectorZywe(temp1);
}

